package com.le.java;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Challenges
 *
 */
public class Challenges {

	/**
	 * @return responseData
	 */
	public static String pollStatus() {

		System.out.println("Polling for status...");

		if (Config.sessionToken.length() == 0)
			return "Invalid token";

		String requestUrl = new StringBuffer(Config.leHostUrl).append("/host/session/")
				.append(Config.sessionToken).append("/").append(Config.agentId).toString();

		String responseData = Service.MakeGetRequest(requestUrl).toString();

		System.out.println(responseData);

		return responseData;
	}

	/**
	 * @param question
	 * @param answer
	 * @return responseData
	 */
	public static Map<String, Object> addPromptChallenge(String question, String answer) {

		String type = "PROMPT";
		String required = "true";
		String fallback = "0";
		String maxAt = "1";

		Map<String, String> challengeDetails = new HashMap<>();
		challengeDetails.put("question", question);
		challengeDetails.put("answer", answer);
		challengeDetails.put("required", required);
		challengeDetails.put("fallbackChallengeID", fallback);
		challengeDetails.put("maximumAttempts", maxAt);

		Map<String, Object> data = new HashMap<>();
		data.put("sessionToken", Config.sessionToken);
		data.put("challengeType", type);
		data.put("agentId", Config.agentId);
		data.put("challengeDetails", challengeDetails);

		System.out.println("Adding a Promote challenge ..." + data);

		String requestUrl = new StringBuffer(Config.leHostUrl).append("/host/challenge").toString();

		Map<String, Object> responsedata = Service.MakePutRequest(requestUrl, data, "application/json");

		System.out.println(responsedata);

		return responsedata;
	}

	/**
	 * @param orientation
	 * @param touches
	 * @return responseData
	 */
	public static Map<String, Object> addTouchChallenge(String orientation, String touches) {

		String type = "HOST_BEHAVIOR"; // Required
		String regionCount = "6"; // Grid pattern
		String required = "true"; // Required
		String fallback = "0"; // Required
		String maxAt = "1"; // Max retries

		Map<String, String> details = new HashMap<>();
		details.put("orientation", orientation);
		details.put("touches", touches);
		details.put("regionCount", regionCount);
		details.put("required", required);
		details.put("fallbackChallengeID", fallback);
		details.put("maximumAttempts", maxAt);

		Map<String, Object> data = new HashMap<>();
		data.put("sessionToken", Config.sessionToken);
		data.put("challengeType", type);
		data.put("agentId", Config.agentId);
		data.put("challengeDetails", details);

		System.out.println("Adding a touch challenge ..." + data);

		String requestUrl = new StringBuffer(Config.leHostUrl).append("/host/challenge").toString();

		Map<String, Object> responseData = Service.MakePutRequest(requestUrl, data, "application/json");

		System.out.println(responseData);

		return responseData;
	}

	/**
	 * @param latitude
	 * @param longitude
	 * @param radius
	 * @return responseData
	 */
	public static Map<String, Object> addLocationChallenge(String latitude, String longitude, String radius) {

		String type = "LAT_LONG"; // Required
		String required = "true"; // Required
		String fallback = "0"; // If fail, other challenge
		String maxAt = "1"; // Retries

		Map<String, String> details = new HashMap<>();
		details.put("latitude", latitude);
		details.put("longitude", longitude);
		details.put("radius", radius);
		details.put("required", required);
		details.put("fallbackChallengeID", fallback);
		details.put("maximumAttempts", maxAt);

		Map<String, Object> data = new HashMap<>();
		data.put("sessionToken", Config.sessionToken);
		data.put("challengeType", type);
		data.put("agentId", Config.agentId);
		data.put("challengeDetails", details);

		System.out.println("Adding location challenge ... " + data);

		String requestUrl = new StringBuffer(Config.leHostUrl).append("/host/challenge").toString();

		Map<String, Object> responseData = Service.MakePutRequest(requestUrl, data, "application/json");

		System.out.println(responseData);

		return responseData;
	}

}