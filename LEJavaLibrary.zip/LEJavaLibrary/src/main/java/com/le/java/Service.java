package com.le.java;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import okhttp3.Call;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * @author Service
 *
 */
class Service {

	/**
	 * @param requestUrl
	 * @return responseData
	 */
	static Map<String, Object> MakeGetRequest(String requestUrl) {
		Gson gson = new Gson();
		System.out.println("Get Request Url =========================================== " + requestUrl);
		try {
			OkHttpClient client = new OkHttpClient().newBuilder().followRedirects(false).build();
			Request request = new Request.Builder().url(requestUrl).build();

			Call call = client.newCall(request);
			Response response = call.execute();

			if (!response.isSuccessful())
				throw new Exception(
						"Server error (HTTP {0}: {1}). " + response.code() + " message : " + response.message());

			String responseBody = response.body().string();
			System.out.println("String Response =========================================== " + responseBody);

			Map<String, Object> objResponse = gson.fromJson(responseBody, new TypeToken<HashMap<String, Object>>() {
			}.getType());

			return objResponse;
		} catch (IOException ex) {
			System.out.println(ex.getMessage());
			return null;
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			return null;
		}
	}

	/**
	 * @param requestUrl
	 * @param JSONRequest
	 * @param JSONContentType
	 * @return responseData
	 */
	static Map<String, Object> MakePutRequest(String requestUrl, Map<String, Object> JSONRequest,
			String JSONContentType) {
		Gson gson = new Gson();
		System.out.println("Get Request Url =========================================== " + requestUrl);
		try {
			String json = gson.toJson(JSONRequest);

			OkHttpClient client = new OkHttpClient.Builder().build();
			Request request = new Request.Builder().url(requestUrl)
					.put(RequestBody.create(json, MediaType.parse(JSONContentType))).build();

			Call call = client.newCall(request);
			Response response = call.execute();

			if (response.code() != 200)
				throw new Exception(
						"Server error (HTTP {0}: {1}). " + response.code() + " message : " + response.message());

			String responseBody = response.body().string();
			System.out.println("String Response =========================================== " + responseBody);

			Map<String, Object> objResponse = gson.fromJson(responseBody, new TypeToken<HashMap<String, Object>>() {
			}.getType());

			return objResponse;
		} catch (IOException ex) {
			System.out.println(ex.getMessage());
			return null;
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			return null;
		}
	}

}
