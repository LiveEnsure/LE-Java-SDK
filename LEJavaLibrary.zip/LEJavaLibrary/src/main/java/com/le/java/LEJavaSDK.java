package com.le.java;

public class LEJavaSDK {
	public static void main(String[] args) {
		Config.leStartSession(args[0], args[1], args[2], args[3]);
//		Config.leStartSession("ananda1@damcogroup.com", "2cbdebd7-fd3d-4a27-a096-4c66089ca75e", "5a065456-35c1-4fb2-8346-5909c0c9985a", "vDLniryXQXTdvxLZ");
	}
	/*
	 * public void show() { System.out.println("testing API calling");
	 * HttpURLConnection conn = null; Gson gson = new Gson(); try {
	 * //HttpURLConnection URL url = new
	 * URL("https://jsonmock.hackerrank.com/api/movies/search/?Title=spiderman");
	 * System.out.
	 * println("Get Request Url =========================================== " +
	 * url); conn = (HttpURLConnection) url.openConnection();
	 * conn.setRequestMethod("GET"); conn.setRequestProperty("Accept",
	 * "application/json");
	 * 
	 * if (conn.getResponseCode() != 200) { throw new
	 * RuntimeException("Failed : HTTP error code : " + conn.getResponseCode()); }
	 * 
	 * BufferedReader br = new BufferedReader(new InputStreamReader(
	 * (conn.getInputStream())));
	 * 
	 * String output; System.out.println("Output from Server .... \n"); while
	 * ((output = br.readLine()) != null) { System.out.println(output); }
	 * 
	 * // OKHTTP String requestUrl =
	 * "https://jsonmock.hackerrank.com/api/movies/search/?Title=spiderman"; int
	 * cacheSize = 10 * 1024 * 1024; Map<String, Object> JSONRequest = null; String
	 * json = gson.toJson(JSONRequest); String JSONContentType = "application/json";
	 * File cacheDirectory = new File("src/test/resources/cache"); Cache cache = new
	 * Cache(cacheDirectory, cacheSize); OkHttpClient client = new
	 * OkHttpClient.Builder() .cache(cache).readTimeout(1, TimeUnit.SECONDS)
	 * .followRedirects(false) .build();
	 * 
	 * // POST call
	 * 
	 * RequestBody body = RequestBody.create(json,
	 * MediaType.parse(JSONContentType));
	 * 
	 * Request request = new Request.Builder().url(requestUrl) .header("", "")
	 * .addHeader("Content-Type", JSONContentType) .put(body).build();
	 * 
	 * Call call = client.newCall(request); Response response = call.execute();
	 * 
	 * if (response.code() != 200) throw new
	 * Exception("Server error (HTTP {0}: {1})." + response.code() +
	 * response.message());
	 * 
	 * String responseBody = response.body().string();
	 * 
	 * System.out.println("Response before parsing ==================" +
	 * responseBody);
	 * 
	 * Type type = new TypeToken<HashMap<String, Object>>() { }.getType();
	 * Map<String, Object> objResponse = gson.fromJson(responseBody, type);
	 * System.out.println(objResponse);
	 * 
	 * //GET Call request = new Request.Builder().url(requestUrl).build();
	 * 
	 * call = client.newCall(request); response = call.execute(); responseBody =
	 * response.body().string();
	 * 
	 * System.out.
	 * println("String Respone =========================================== " +
	 * responseBody);
	 * 
	 * type = new TypeToken<HashMap<String, Object>>() { }.getType(); objResponse =
	 * gson.fromJson(responseBody, type);
	 * 
	 * System.out.println(objResponse);
	 * 
	 * } catch (IOException e) { System.out.println(e.getMessage()); } catch
	 * (Exception e) { System.out.println(e.getMessage()); } finally {
	 * conn.disconnect(); } }
	 */
}
