package com.le.java;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Config
 *
 */
public class Config {

	// --------------------------------------------------------------
	// Standard API Variables [ DO NOT EDIT ]

	static String apiVersion = "5";
	static String pubHostBase = "https://app.liveensure.com/live-identity";
	static String leHostBase = "https://app.liveensure.com/live-identity";
	static String leHostUrl = leHostBase + "/rest";
	static String stackLocation = "US";
	static String sessionToken = "";
	static String log = "";
	static boolean DEBUG = false;

	// --------------------------------------------------------------
	// Developer Variables [ EDIT FOR YOUR ACCOUNT INFO ]

	static String agentId = ""; // your agentID

	// --------------------------------------------------------------
	/**
	 * Make an request to get authonticate and get a sessionToken in Response
	 * 
	 * @param userId
	 * @return sessionToken
	 */
	public static String leStartSession(String userId, String agentId, String apiKey, String apiPass) {
		
		Config.agentId = agentId;
		System.out.println("Start Session Called......................");
		Map<String, Object> loginParams = new HashMap<>();
		loginParams.put("apiVersion", apiVersion);
		loginParams.put("userId", userId);
		loginParams.put("agentId", agentId);
		loginParams.put("apiKey", apiKey);

		String requestUrl = new StringBuffer(leHostUrl).append("/host/session").toString();
		Map<String, Object> data = Service.MakePutRequest(requestUrl, loginParams, "application/json");

		sessionToken = data.get("sessionToken").toString();

		System.out.println(data);
		System.out.println(sessionToken);

		return sessionToken;
	}
}
